#include<stdio.h>
#include<assert.h>

int ascending_sort(int *);
int descending_sort(int *);

int main()
{
	int arr_input[10],i;

	printf("Enter ten numbers:\n");
	for(i = 0; i < 10; i++)
		scanf("%d",&arr_input[i]);

	ascending_sort(arr_input);
	descending_sort(arr_input);

	return 0;
}

int ascending_sort(int *ptr)
{
	int i,j,ref_arr[10];

	for(i = 0; i < 10; i++)
	{
		ref_arr[i] = *ptr;
		ptr++;
	}

	for(i = 0; i < 10; i++)
	{
		for(j = i+1; j < 10; j++)
		{
			if(ref_arr[i] > ref_arr[j])
			{
				ref_arr[i] += ref_arr[j];
				ref_arr[j] = ref_arr[i] - ref_arr[j];
				ref_arr[i] -= ref_arr[j];
			}
		}
	}
	
	printf("The sorted array in ascending order is:\n");
	for(i = 0; i < 10; i++)
		printf("%d\n",ref_arr[i]);

	return 0;
}

int descending_sort(int *ptr)
{
	int i,j,ref_arr[10];

	for(i = 0; i < 10; i++)
	{
		ref_arr[i] = *ptr;
		ptr++;
	}

	for(i = 0; i < 10; i++)
	{
		for(j = i+1; j < 10; j++)
		{
			if(ref_arr[i] < ref_arr[j])
			{
				ref_arr[i] += ref_arr[j];
				ref_arr[j] = ref_arr[i] - ref_arr[j];
				ref_arr[i] -= ref_arr[j];
			}
		}
	}
	
	printf("The sorted array in descending order is:\n");
	for(i = 0; i < 10; i++)
		printf("%d\n",ref_arr[i]);

	return 0;
}