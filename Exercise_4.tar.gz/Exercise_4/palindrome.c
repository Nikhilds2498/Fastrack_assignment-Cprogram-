#include<stdio.h>
#include<string.h>
#include<assert.h>

char pali_check(char *);

int main()
{
	char input[100],ch;
	int length;

	printf("Enter a string:\n");
	fgets(input,100,stdin);

	ch = pali_check(input);

	if(ch == 'y')
		printf("The string is a palindrome.\n");
	else
		printf("The string is not a palindrome.\n");

	//assert(pali_check("malayalam") == 'y');
	//assert(pali_check("Test") == 'n');

	return 0;
}

char pali_check(char *ptr)
{
	int length,n,i;
	char temp;

	length = strlen(ptr);
	n = 0;
	temp = length - 2;

	while(n <= length/2)
	{
		if(ptr[n] != ptr[temp])
			return 'n';

		n++;
		temp--;
	}

	return 'y';
}